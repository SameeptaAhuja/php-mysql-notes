<?php 
	If(isset($_POST['back'])){
		header("refresh:0; url= customerShoptab.php");
		exit();
	}
 ?>